#include "Service.h"
#include "Stock.h"
#include <iostream>

void WarehouseService::createStock() {
	
}

void WarehouseService::displayStock() {
	Stock::displayProducts();
}