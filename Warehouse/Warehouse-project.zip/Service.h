#ifndef __SERVICE_
#define __SERVICE_

class WarehouseService {
public:
	static void createStock();
	static void displayStock();
};

#endif
